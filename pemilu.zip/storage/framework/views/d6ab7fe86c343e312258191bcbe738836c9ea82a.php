<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('plugins/morris/morris.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('dist/css/AdminLTE.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="content-header">
    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('home-admin')); ?>"><i class="fa fa-home"></i> Home</a></li>
    </ol>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
         <center> <h1> <b> Aplikasi Pemilihan Ketua Organisasi</b> <BR/> Universitas CIC CIREBON </h1> </center>      
      </div>
    </div>
    <br/>
    <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-sort-amount-asc"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Jumlah Pemilih</span>
              <span class="info-box-number"><?php echo e($total_pemilih); ?></span>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-check"></i></span>
            <div class="info-box-content">
              <span class="info-box-text">Sudah Memilih</span>
              <span class="info-box-number"><?php echo e($sudah_memilih); ?></span>
            </div>
          </div>
        </div>

        <div class="clearfix visible-sm-block"></div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-close"></i></span>

            <div class="info-box-content">
              <span class="info-box-text"> Belum Memilih</span>
              <span class="info-box-number"><?php echo e($belum_memilih); ?></span>
            </div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 col-xs-12">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-users"></i></span>

            <div class="info-box-content">
              <span class="info-box-text">Jumlah Calon</span>
              <span class="info-box-number"><?php echo e($jumlah_calon); ?></span>
            </div>
          </div>
        </div>
    </div>
      <div class="row">
      <div class="col-sm-12">
      <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Grafik Hasil Suara</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
               <!--  <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button> -->
              </div>
            </div>
            <div class="box-body chart-responsive">
              <div class="chart" id="bar-chart" style="height: 300px;"></div>
            </div>
          </div>
        </div>
      </div>
  </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('plugins/morris/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/raphael/raphael-min.js')); ?>"></script>
<script>

  var bar = new Morris.Bar({
        element: 'bar-chart',
        resize: true,
        data: [
     <?php foreach($hasil_suara as $key => $value): ?>
          {n: '<?php echo e($value->nama_calon); ?>', a: <?php echo e($value->hasil_suara); ?>},
     <?php endforeach; ?>
        ],
        barColors: ['#f56954','#00a65a', '#f56954'],
        xkey: 'n',
        ykeys: 'a',
        labels: 'Jumlah Suara',
        hideHover: 'auto'
      });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>