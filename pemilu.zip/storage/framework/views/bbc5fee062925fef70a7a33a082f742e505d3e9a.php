<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content-header">
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('home-admin')); ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active"> Akses</li>
      </ol>
      <br/>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-sm-6 col-sm-offset-3">
            <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Configurasi :</h3>
                  <div class="box-tools pull-right">
                  </div>
                </div>
               <div class="box-body">
                <?php if(\Session::has('msg_info')): ?>
                <div class="alert alert-info">
                  <?php echo e(\Session::get('msg_info')); ?>

                </div>
                <?php endif; ?>
                <form id="formakses" action="<?php echo e(route('update_akses')); ?>" method="post" class="form-horizontal">
                  <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label for="inputTangal" class="col-sm-4 control-label">Tanggal</label>
                  <div class="col-sm-8">
                    <input type="date" class="form-control" value="<?php echo e($tanggal); ?>" name="tanggal" placeholder="Tanggal">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputWaktu" class="col-sm-4 control-label">Waktu</label>
                  <div class="col-sm-8">
                    <input type="time" class="form-control" value="<?php echo e($waktu); ?>" name="waktu" placeholder="Waktu">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputWaka" class="col-sm-4 control-label">Kemahasiswaan</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" value="<?php echo e($wakasek); ?>" name="wakepsek" placeholder="Waka Kesiswaan">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputNipWaka" class="col-sm-4 control-label">NIP Kemahasiswaan</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" value="<?php echo e($nipwakasek); ?>" name="nipwakepsek" placeholder="Nip Waka Kesiswaan">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputKepalaSekolah" class="col-sm-4 control-label">Rektor</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" value="<?php echo e($kepsek); ?>" name="kepsek" placeholder="Kepala Sekolah">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputNipKepalaSekolah" class="col-sm-4 control-label">NIP REKTOR</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" value="<?php echo e($nipkepsek); ?>" name="nipkepsek" placeholder="Nip Kepala Sekolah">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputKetuaPemilu" class="col-sm-4 control-label">Ketua Pemilu</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" value="<?php echo e($ketuapemilu); ?>" name="ketuapemilu" placeholder="Ketua Pemilu">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputNisKetuaPemilu" class="col-sm-4 control-label">NIM Ketua Pemilu</label>
                  <div class="col-sm-8">
                    <input type="text" class="form-control" value="<?php echo e($nisketua); ?>" name="nisketua" placeholder="Nis Ketua Pemilu">
                  </div>
                </div>
               </form>
              </div>
              <div class="box-footer">
                <button form="formakses" type="submit" class="btn btn-info pull-right">Simpan</button>
              </div>
            </div> 
          </div>
        </div>
      </section>           
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>