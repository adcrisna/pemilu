<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('plugins/morris/morris.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content-header">
      <ol class="breadcrumb">
        <li><a href="<?php echo e(route('home-admin')); ?>"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Hasil Suara</li>
      </ol>
      <br/>
    </section>
  <section class="content">
    <div class="row">
      <div class="col-xs-6">
              <?php if(\Session::has('msg_cari')): ?>
                <div class="alert alert-warning">
                  <?php echo e(\Session::get('msg_cari')); ?>

                </div>
                <?php endif; ?>
                <?php if(\Session::has('msg_reset')): ?>
                <div class="alert alert-danger">
                  <?php echo e(\Session::get('msg_reset')); ?>

                </div>
                <?php endif; ?>
          <div class="box box-info">
              <div class="box-header">
                <h3 class="box-title">Hasil Suara</h3>
                <div class="box-tools pull-right">
                  <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#modal-reset"><i class="fa fa-refresh"> Reset</i></button>
                </div>
             </div>
              <div class="box-body">
                <form action="<?php echo e(route('cari_hapus')); ?>" method="post" enctype="multipart/form-data">
                     <?php echo e(csrf_field()); ?>

                  <div class="form-group">
                  <input type="text" class="form-control" name="ceknis" placeholder="Masukan NIS">
                  </div>
                  <button class="btn btn-warning"><i class="fa fa-search"> Cari & Hapus </i></button>
                </form>
                <br/>
                 <table class="table table-bordered table-striped" id="hasil-suara">
            <thead>
              <tr>
                <th>ID Calon</th>
                <th>Nama Ketua</th>
                <th>Nama Wakil</th>
                <th>Jumlah Suara</th>
              </tr>
            </thead>
              <tbody>
                 <?php foreach($hasil_suara as $key => $value): ?>
                    <tr>
                      <td><?php echo e($value->id_calon); ?></td>
                      <td><?php echo e($value->nama_calon); ?></td>
                      <td><?php echo e($value->nama_wakil); ?></td>
                      <td><?php echo e($value->hasil_suara); ?></td>
                    </tr>
                    <?php endforeach; ?>
              </tbody>
          </table>
           </div>
       </div>         
      </div>
      <div class="col-xs-6">
        <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">Grafik Hasil Suara</h3>

              <div class="box-tools pull-right">
                <a href="<?php echo e(route('cetak-berita-acara')); ?>"><button class="btn btn-info"> Cetak Berita Acara</button></a>
              </div>
            </div>
            <div class="box-body chart-responsive">
              <div class="chart" id="bar-chart" style="height: 300px;"></div>
            </div>
          </div>
      </div>
    </div>
  </section>
    <div class="modal fade" id="modal-reset" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">

        <div class="modal-header">
          <h4 class="modal-title">Apakah anda yakin ingin mereset semua hasil suara?</h4>
        </div>
        <div class="modal-body">
          <form action="<?php echo e(route('reset_hasil_suara')); ?>" method="post" class="text-center form-reset">
            <?php echo e(csrf_field()); ?>

          <button type="submit" name="id_calon" class="btn btn-lg btn-primary">Iya</button>
          <button type="button" class="btn btn-lg btn-default" data-dismiss="modal">Tidak</button>
        </form>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/raphael/raphael-min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/morris/morris.min.js')); ?>"></script>
<script type="text/javascript">
  var table = $('#hasil-suara').DataTable();

    var bar = new Morris.Bar({
        element: 'bar-chart',
        resize: true,
        data: [
     <?php foreach($hasil_suara as $key => $value): ?>
          {n: '<?php echo e($value->nama_calon); ?>', a: <?php echo e($value->hasil_suara); ?>},
     <?php endforeach; ?>
        ],
        barColors: ['#00a65a', '#f56954'],
        xkey: 'n',
        ykeys: 'a',
        labels: 'Jumlah Suara',
        hideHover: 'auto'
      });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>